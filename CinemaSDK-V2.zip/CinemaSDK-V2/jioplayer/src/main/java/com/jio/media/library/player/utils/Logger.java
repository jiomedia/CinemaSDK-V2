package com.jio.media.library.player.utils;

import android.util.Log;

public class Logger
{
    public static void d(String s) {
        Log.d("CinemaSDK-V2", s);
    }
}
