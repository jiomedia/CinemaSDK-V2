package com.jio.media.library.player;

import android.widget.ImageView;

public interface MediaThumbListener
{
    void onThumbImageViewReady(ImageView imageView);
}
